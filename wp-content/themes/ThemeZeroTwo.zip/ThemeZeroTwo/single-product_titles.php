<?php
get_header();
$thumbnail_url  = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$title_banner   = get_field('title_banner');
$title_category_array = get_field('title_category');
$category_count = count($title_category_array);
?>

<!-- ===FEATURE IMAGE=== -->
<?php if( $title_banner ) { ?>
  <section class="feature-image" style="background:url('<?php echo $title_banner['url']; ?>') no-repeat; background-size:cover;" data-type="background" data-speed="2">
    <h1 class="page-title"><?php the_title(); ?></h1>
  </section>
<?php } else { ?>
  <section class="feature-image feature-image-default" data-type="background" data-speed="2">
    <h1 class="page-title"><?php the_title(); ?></h1>
  </section>
<?php }

$categories  = "'";
foreach($title_category_array as $iteration => $value) {
  $category_slug = $value->slug;
  $categories .= $category_slug;
  if($category_count==($iteration+1)){
    $categories .= "'";
  }
  else {
    $categories .= ",";
  }
  $iteration++;
}
echo $categories;

$loop = new WP_Query( array(  'posts_per_page' => 16,
                              'post_type' => 'product',
                              'orderby' => 'title',
                              'product_cat' => $categories
                               ) );

while( $loop->have_posts() ) :
  $loop->the_post();
    the_post_thumbnail( 'medium' );
endwhile; wp_reset_postdata();
?>

<?php
get_footer();
?>
