<!-- SIGN UP SECTION -->
<section id="signup" style="background: url('/wp-content/themes/ThemeZeroTwo/assets/img/shenron-parallax.png') 50% 50%/cover repeat-y fixed;" data-type="background">

	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-sm-offset-3">
				<h2>Sign up for the newsletter <strong>for free food</strong>!</h2>
				<p><a href="#" class="btn btn-lg btn-block btn-success" data-toggle="modal" data-target="#myModal">Yes, sign me up!</a></p>
			</div>
			<!-- end col -->
		</div>
		<!-- end row -->
	</div>
	<!-- end container -->
</section>
<!-- signup -->
